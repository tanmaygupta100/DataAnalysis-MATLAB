%{
***************************************************************************
File name: evaluateIntegral.m
Programmmer name: Tanmay Gupta
Date created: 06/24/2020
Date of last revision: 06/24/2020
Details of the revision: None
Short description: Function evaluates integral for hw_week6_P3.m
***************************************************************************
%}

function [ind_intg] = evaluateIntegral(f)
% function calculates the integral

ind_intg = int(f);
end